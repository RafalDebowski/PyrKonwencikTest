package com.example.pyrkonwenciknew.ui

enum class NavigationType {
    GuestList,
    GuestDetails
}