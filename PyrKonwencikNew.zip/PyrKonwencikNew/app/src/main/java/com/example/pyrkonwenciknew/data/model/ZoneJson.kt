package com.example.pyrkonwenciknew.data.model

import com.google.gson.annotations.SerializedName

data class ZoneJson(
    @SerializedName("name") val name: String
)