package com.example.pyrkonwenciknew.data.repository

import android.content.Context
import com.example.pyrkonwenciknew.data.api.GuestAPI
import com.example.pyrkonwenciknew.data.api.MockGuestAPI
import com.example.pyrkonwenciknew.data.api.RetrofitClientRepository
import com.example.pyrkonwenciknew.data.api.requestHandler
import com.example.pyrkonwenciknew.data.mapper.toGuestDomainList
import com.example.pyrkonwenciknew.domain.BaseResponse
import com.example.pyrkonwenciknew.domain.model.GuestDomain
import com.example.pyrkonwenciknew.domain.repository.GuestRepository

class GuestRepositoryImpl(
    private val context: Context,
    private val retrofitClientRepository: RetrofitClientRepository
) : GuestRepository {

    override suspend fun getGuestsList(): BaseResponse<List<GuestDomain>> {
        val response = requestHandler {
            MockGuestAPI(context).getGuestsList() //todo mock
//            retrofitClientRepository
//                .getRetrofitInterface()
//                .create(GuestAPI::class.java)
//                .getGuestsList()
        }

        return when {
            response.isSuccessful() && response.data != null -> {
                BaseResponse.success(
                    data = response.data.toGuestDomainList(),
                    code = response.code
                )
            }

            else -> {
                BaseResponse.error(
                    errorMessage = response.errorMessage.orEmpty(),
                    code = response.code
                )
            }
        }
    }
}