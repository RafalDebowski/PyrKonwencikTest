package com.example.pyrkonwenciknew.di

import android.content.Context
import com.example.pyrkonwenciknew.data.api.RetrofitClientRepository
import com.example.pyrkonwenciknew.data.repository.GuestRepositoryImpl
import com.example.pyrkonwenciknew.domain.repository.GuestRepository
import com.example.pyrkonwenciknew.domain.usecase.GuestListUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
class GuestModule {

    @Provides
    fun provideGuestRepository(
        @ApplicationContext appContext: Context,
        retrofitClientRepository: RetrofitClientRepository
    ): GuestRepository =
        GuestRepositoryImpl(
            appContext,
            retrofitClientRepository
        )

    @Provides
    fun provideGuestListUseCase(
        guestRepository: GuestRepository
    ) :GuestListUseCase =
        GuestListUseCase(guestRepository)
}
