package com.example.pyrkonwenciknew.domain.model

data class ZoneDomain(
    val name: String
)