package com.example.pyrkonwenciknew.di

import com.example.pyrkonwenciknew.data.api.RetrofitClientRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
class ApiModule {

    @Provides
    fun bindRetrofitClientRepository(): RetrofitClientRepository =
        RetrofitClientRepository()
}